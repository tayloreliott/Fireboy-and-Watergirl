import pygame

class Hazards:
    def __init__(self, virtual_w, virtual_h, wall_thickness, lava_path, water_path,
                 lava_x=None, water_x=None, brick_w=None):
        lava_raw = pygame.image.load(lava_path).convert_alpha()
        water_raw = pygame.image.load(water_path).convert_alpha()
        scaled_h = round(wall_thickness * 0.6)
        scaled_w = round(brick_w * 2.0) if brick_w else round(lava_raw.get_width() * scaled_h / lava_raw.get_height())
        self.lava = pygame.transform.scale(lava_raw, (scaled_w, scaled_h))
        self.water = pygame.transform.scale(water_raw, (scaled_w, scaled_h))
        if lava_x is None:
            lava_x = virtual_w // 4 - scaled_w // 2
        if water_x is None:
            water_x = virtual_w // 2 - scaled_w // 2
        self.lava_x = lava_x
        self.water_x = water_x
        self.pool_y = virtual_h - wall_thickness - round(wall_thickness * 0.15)
        water_rect_w = round(scaled_w * 0.75)
        water_rect_h = round(scaled_h * 0.75)
        water_rect_x = water_x + (scaled_w - water_rect_w) // 2
        water_rect_y = self.pool_y + (scaled_h - water_rect_h) // 2
        self.water_rect = pygame.Rect(water_rect_x, water_rect_y, water_rect_w, water_rect_h)

    def check(self, player):
        if player.get_hazard_rect().colliderect(self.water_rect):
            player.reset()

    def draw(self, surface):
        surface.blit(self.lava, (self.lava_x, self.pool_y))
        surface.blit(self.water, (self.water_x, self.pool_y))
