import pygame
from player import Player
from walls import Walls
from hazards import Hazards
from platforms import Platform, ColumnPlatform

def main():
    pygame.init()
    virtual_w, virtual_h = 1447, 1024
    display_w, display_h = 1085, 768
    screen = pygame.display.set_mode((display_w, display_h))
    virtual_surface = pygame.Surface((virtual_w, virtual_h))
    bg_raw = pygame.image.load("background.png").convert()
    background = pygame.transform.scale(bg_raw, (virtual_w, virtual_h))

    BRICK_W, BRICK_H = 76, 38

    walls = Walls(virtual_w, virtual_h, "brick.png", brick_size=(BRICK_W, BRICK_H))

    num_bricks = 6
    platform_end_x = walls.side_thickness + BRICK_W * num_bricks

    _lava_raw = pygame.image.load("lava.png")
    _lava_h = _lava_raw.get_height()
    _lava_scaled_w = round(_lava_raw.get_width() * round(BRICK_H * 1.5) / _lava_h)
    lava_x  = platform_end_x + 3 * BRICK_W - 2 * BRICK_W
    water_x = lava_x + round(BRICK_W * 2.0) + 2 * BRICK_W

    hazards = Hazards(virtual_w, virtual_h, walls.wall_thickness, "lava.png", "water.png",
                      lava_x=lava_x, water_x=water_x, brick_w=BRICK_W)

    start_x = walls.side_thickness
    start_y = virtual_h - walls.wall_thickness - 3 * BRICK_H 

    player = Player("fireboyspritesheet.png", start_x, start_y,
                    speed=5, jump_strength=-15, gravity=0.5)

    platform = Platform(
        x=walls.side_thickness,
        y=virtual_h - walls.wall_thickness - 150,
        num_bricks=num_bricks,
        brick_path="brick.png",
        brick_size=(BRICK_W, BRICK_H)
    )

    upper_platform = Platform(
        x=walls.side_thickness,
        y=virtual_h - walls.wall_thickness - 150 - 3 * BRICK_H - BRICK_H,
        num_bricks=14,
        brick_path="brick.png",
        brick_size=(BRICK_W, BRICK_H)
    )

    corner_platform = ColumnPlatform(
        x=virtual_w - walls.side_thickness - BRICK_W * 2,
        y=virtual_h - walls.wall_thickness - BRICK_H * 3,
        cols=2,
        rows=1,
        brick_path="brick.png",
        brick_size=(BRICK_W, BRICK_H)
    )

    right_platform = Platform(
        x=virtual_w - walls.side_thickness - BRICK_W * 16,
        y=virtual_h - walls.wall_thickness - BRICK_H * 13,
        num_bricks=16,
        brick_path="brick.png",
        brick_size=(BRICK_W, BRICK_H)
    )

    left_upper_platform = Platform(
        x=walls.side_thickness,
        y=virtual_h - walls.wall_thickness - BRICK_H * 13 - 3 * BRICK_H - BRICK_H,
        num_bricks=16,
        brick_path="brick.png",
        brick_size=(BRICK_W, BRICK_H)
    )

    gameClock = pygame.time.Clock()
    RUNNING = True
    while RUNNING:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                RUNNING = False
            player.handle_event(event)

        player.update(walls.rects + [platform.rect, corner_platform.rect, upper_platform.rect, right_platform.rect, left_upper_platform.rect])
        hazards.check(player)

        virtual_surface.blit(background, (0, 0))
        walls.draw(virtual_surface)
        hazards.draw(virtual_surface)
        platform.draw(virtual_surface)
        upper_platform.draw(virtual_surface)
        corner_platform.draw(virtual_surface)
        right_platform.draw(virtual_surface)
        left_upper_platform.draw(virtual_surface)
        player.draw(virtual_surface)

        scaled = pygame.transform.scale(virtual_surface, (display_w, display_h))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()
        gameClock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()
