import pygame

class Platform:
    def __init__(self, x, y, num_bricks, brick_path, brick_size=None):
        brick_raw = pygame.image.load(brick_path).convert_alpha()
        if brick_size:
            self.brick = pygame.transform.scale(brick_raw, brick_size)
        else:
            self.brick = brick_raw
        self.brick_w = self.brick.get_width()
        self.brick_h = self.brick.get_height()
        self.x = x
        self.y = y
        self.num_bricks = num_bricks
        self.rect = pygame.Rect(x, y, self.brick_w * num_bricks, self.brick_h)

    def draw(self, surface):
        for i in range(self.num_bricks):
            surface.blit(self.brick, (self.x + i * self.brick_w, self.y))


class ColumnPlatform:
    def __init__(self, x, y, cols, rows, brick_path, brick_size=None):
        brick_raw = pygame.image.load(brick_path).convert_alpha()
        if brick_size:
            self.brick = pygame.transform.scale(brick_raw, brick_size)
        else:
            self.brick = brick_raw
        self.brick_w = self.brick.get_width()
        self.brick_h = self.brick.get_height()
        self.x = x
        self.y = y
        self.cols = cols
        self.rows = rows

        full_cols = int(cols)
        partial = cols - full_cols
        if partial > 0:
            partial_w = round(self.brick_w * partial)
            self.partial_brick = self.brick.subsurface(
                pygame.Rect(0, 0, partial_w, self.brick_h))
        else:
            self.partial_brick = None

        total_w = round(self.brick_w * cols)
        total_h = self.brick_h * rows
        self.rect = pygame.Rect(x, y, total_w, total_h)

    def draw(self, surface):
        full_cols = int(self.cols)
        for row in range(self.rows):
            row_y = self.y + row * self.brick_h
            for col in range(full_cols):
                surface.blit(self.brick, (self.x + col * self.brick_w, row_y))
            if self.partial_brick:
                surface.blit(self.partial_brick,
                             (self.x + full_cols * self.brick_w, row_y))
