import pygame

BODY_FRAMES = [
    (3,   31, 105, 130),  
    (108, 31, 180, 130),  
    (183, 31, 228, 130),  
    (231, 31, 265, 130),  
    (268, 31, 325, 130),  
    (328, 31, 389, 130),   
    (392, 31, 435, 130),
    (438, 31, 480, 130),  
    (483, 31, 538, 130),  
]

IDLE_FRAMES = [
    (3,   162, 217, 500),
    (220, 162, 434, 500),
    (437, 162, 651, 500),
    (654, 162, 868, 500),
    (871, 162, 1085, 500),
]
FALL_FRAMES = [
    (3,   531, 217, 869),
    (220, 531, 434, 869),
    (437, 531, 651, 869),
    (654, 531, 868, 869),
    (871, 531, 1085, 869),
]
JUMP_FRAMES = [
    (3,   900, 218, 1236),
    (221, 900, 436, 1236),
    (439, 900, 654, 1236),
    (657, 900, 872, 1236),
    (875, 900, 1090, 1236),
]
RUN_FRAMES = [   
    (3,    1267, 344,  1471),
    (347,  1267, 688,  1471),
    (691,  1267, 1032, 1471),
    (1035, 1267, 1376, 1471),
    (1379, 1267, 1720, 1471),
]

WALK_BODY_SEQ = [1, 2, 3, 4, 5, 6, 7, 8]

TEAL = (0, 128, 128, 255)


def _load_sheet(path):
    sheet = pygame.image.load(path).convert_alpha()
    w, h = sheet.get_size()
    sheet.set_colorkey(TEAL[:3])   
    clean = pygame.Surface((w, h), pygame.SRCALPHA)
    clean.fill((0, 0, 0, 0))
    clean.blit(sheet, (0, 0))
    return clean


def _crop_frames(sheet, coords_list, target_w, target_h):
    frames = []
    for (x1, y1, x2, y2) in coords_list:
        sub = sheet.subsurface(pygame.Rect(x1, y1, x2 - x1, y2 - y1))
        frames.append(pygame.transform.scale(sub, (target_w, target_h)))
    return frames


class Player:
    BODY_W = 33
    BODY_H = 41    
    HEAD_W = 71
    HEAD_H = 86

    HEAD_BODY_OVERLAP = 13

    IDLE_FPS = 8
    WALK_FPS = 12
    AIR_FPS  = 8

    def __init__(self, spritesheet_path, x, y, speed, jump_strength, gravity):
        sheet = _load_sheet(spritesheet_path)

        self.idle_frames = _crop_frames(sheet, IDLE_FRAMES, self.HEAD_W, self.HEAD_H)
        self.fall_frames = _crop_frames(sheet, FALL_FRAMES, self.HEAD_W, self.HEAD_H)
        self.jump_frames = _crop_frames(sheet, JUMP_FRAMES, self.HEAD_W, self.HEAD_H)
        self.run_frames  = _crop_frames(sheet, RUN_FRAMES,  self.HEAD_W, self.HEAD_H)

        self.body_idle = _crop_frames(sheet, [BODY_FRAMES[0]], self.BODY_W, self.BODY_H)[0]
        self.body_walk = _crop_frames(sheet,
                                      [BODY_FRAMES[i] for i in WALK_BODY_SEQ],
                                      self.BODY_W, self.BODY_H)

        self.speed         = speed
        self.jump_strength = jump_strength
        self.gravity       = gravity
        self.start_x       = x
        self.start_y       = y
        self.position      = [float(x), float(y)]
        self.velocity      = [0.0, 0.0]
        self.on_ground     = False
        self.facing_right  = True

        self.width  = max(self.HEAD_W, self.BODY_W)
        self.height = self.HEAD_H + self.BODY_H - self.HEAD_BODY_OVERLAP

        self.anim_timer  = 0.0
        self.frame_index = 0

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.velocity[0] = -self.speed
                self.facing_right = False
            elif event.key == pygame.K_RIGHT:
                self.velocity[0] = self.speed
                self.facing_right = True
            elif event.key == pygame.K_UP and self.on_ground:
                self.velocity[1] = self.jump_strength
                self.on_ground   = False
        elif event.type == pygame.KEYUP:
            if event.key in (pygame.K_LEFT, pygame.K_RIGHT):
                self.velocity[0] = 0

    def update(self, walls):
        self.velocity[1] += self.gravity
        self.position[0] += self.velocity[0]
        self.position[1] += self.velocity[1]
        self.on_ground = False

        char_rect = self.get_rect()
        for wall in walls:
            if char_rect.colliderect(wall):
                overlap = char_rect.clip(wall)
                if overlap.width < overlap.height:
                    if char_rect.centerx < wall.centerx:
                        self.position[0] -= overlap.width
                    else:
                        self.position[0] += overlap.width
                else:
                    if char_rect.centery < wall.centery:
                        self.position[1] -= overlap.height
                    else:
                        self.position[1] += overlap.height
                    if self.velocity[1] > 0:
                        self.on_ground = True
                    self.velocity[1] = 0
                char_rect.topleft = (int(self.position[0]), int(self.position[1]))

        moving_x = self.velocity[0] != 0
        in_air   = not self.on_ground
        fps = self.WALK_FPS if moving_x else (self.AIR_FPS if in_air else self.IDLE_FPS)

        self.anim_timer += 1 / 60  
        if self.anim_timer >= 1 / fps:
            self.anim_timer -= 1 / fps
            seq_len = len(self.body_walk) if moving_x else len(self._current_head_frames())
            self.frame_index = (self.frame_index + 1) % seq_len

    def get_rect(self):
        return pygame.Rect(int(self.position[0]), int(self.position[1]),
                           self.width, self.height)

    def get_hazard_rect(self):
        body_x = int(self.position[0]) + (self.width - self.BODY_W) // 2
        body_y = int(self.position[1]) + self.HEAD_H - self.HEAD_BODY_OVERLAP
        return pygame.Rect(body_x, body_y, self.BODY_W, self.BODY_H)

    def reset(self):
        self.position    = [float(self.start_x), float(self.start_y)]
        self.velocity    = [0.0, 0.0]
        self.on_ground   = False
        self.anim_timer  = 0.0
        self.frame_index = 0

    def _current_head_frames(self):
        if self.velocity[1] < -1:       
            return self.jump_frames
        elif self.velocity[1] > 1:      
            return self.fall_frames
        elif self.velocity[0] != 0:    
            return self.run_frames
        else:                         
            return self.idle_frames

    def draw(self, surface):
        moving_x    = self.velocity[0] != 0
        head_frames = self._current_head_frames()

        head_idx = self.frame_index % len(head_frames)
        head_img = head_frames[head_idx]

        if not self.facing_right:
            head_img = pygame.transform.flip(head_img, True, False)

        if moving_x:
            body_idx = self.frame_index % len(self.body_walk)
            body_img = self.body_walk[body_idx]
        else:
            body_img = self.body_idle

        if not self.facing_right:
            body_img = pygame.transform.flip(body_img, True, False)

        px, py = int(self.position[0]), int(self.position[1])

        head_x = px + (self.width - self.HEAD_W) // 2
        head_y = py

        body_x = px + (self.width - self.BODY_W) // 2
        body_y = py + self.HEAD_H - self.HEAD_BODY_OVERLAP

        surface.blit(head_img, (head_x, head_y))
        surface.blit(body_img, (body_x, body_y))
